/**
 * 
 */
/*
var URL = "http://localhost:8079/sampleHospital/webapi";

	function getUsers(){
	console.log("getting the user list");
	$.ajax({
		url:URL + '/users',
		method:'GET',
		datdaType:"xml",
		success:listUsers
	});

	}
	function listUsers(xml,status){
		console.log("listing Users");
		xmlString =(new XMLSerializer().serializeToString(xml));
		console.log('XML String is \n '+xmlString);
		var $outPutUser = $('#outPutUser');
		$outPutUser.empty();
		$outPutUser.Append($('<List  name ="myList">  </List>'))
		
	}

$(document).ready(function(){
$('#getUsers').click(function()){
	$('#list').fadeOut(100);
	getUsers;
});
});
*/