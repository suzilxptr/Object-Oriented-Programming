package com.mycompany.samplehospital.model;

public class nurse {

}
