package com.mycompany.samplehospital.model;

public class LabTechncian {
	/*private String Name;
	private String 
*/
}
